"use client"

import { useState, useEffect } from "react"
import { Calendar, PlusCircle, Users, Settings } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LeaveForm } from "@/components/leave-form"
import { LeaveCalendar } from "@/components/leave-calendar"
import { TeamOverview } from "@/components/team-overview"
import { AdminPanel } from "@/components/admin-panel"
import {
  saveTeamMembers,
  loadTeamMembers,
  saveLeaveRequests,
  loadLeaveRequests,
  saveDepartments,
  loadDepartments,
  initializeDefaultData,
} from "@/utils/storage"

export type LeaveRequest = {
  id: string
  employeeName: string
  employeeId: string
  startDate: string
  endDate: string
  leaveType: "vacation" | "sick" | "personal" | "maternity" | "paternity"
  reason: string
  submittedDate: string
}

export type TeamMember = {
  id: string
  name: string
  email: string
  department: string
  avatar?: string
}

export type Department = {
  id: string
  name: string
  createdDate: string
}

export default function TeamLeaveApp() {
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([])
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  // Load data from localStorage on component mount
  useEffect(() => {
    initializeDefaultData()
    setTeamMembers(loadTeamMembers())
    setLeaveRequests(loadLeaveRequests())
    setDepartments(loadDepartments())
    setIsLoaded(true)
  }, [])

  // Save data whenever state changes
  useEffect(() => {
    if (isLoaded) {
      saveTeamMembers(teamMembers)
    }
  }, [teamMembers, isLoaded])

  useEffect(() => {
    if (isLoaded) {
      saveLeaveRequests(leaveRequests)
    }
  }, [leaveRequests, isLoaded])

  useEffect(() => {
    if (isLoaded) {
      saveDepartments(departments)
    }
  }, [departments, isLoaded])

  const handleAddMember = (newMember: Omit<TeamMember, "id">) => {
    const member: TeamMember = {
      ...newMember,
      id: Date.now().toString(),
    }
    setTeamMembers((prev) => [...prev, member])
  }

  const handleEditMember = (updatedMember: TeamMember) => {
    setTeamMembers((prev) => prev.map((member) => (member.id === updatedMember.id ? updatedMember : member)))
  }

  const handleDeleteMember = (memberId: string) => {
    setTeamMembers((prev) => prev.filter((member) => member.id !== memberId))
    // Also remove any leave requests for this member
    setLeaveRequests((prev) => prev.filter((leave) => leave.employeeId !== memberId))
  }

  const handleAddDepartment = (name: string) => {
    const department: Department = {
      id: Date.now().toString(),
      name,
      createdDate: new Date().toISOString().split("T")[0],
    }
    setDepartments((prev) => [...prev, department])
  }

  const handleEditDepartment = (departmentId: string, newName: string) => {
    const oldDepartment = departments.find((dept) => dept.id === departmentId)
    if (!oldDepartment) return

    // Update department name
    setDepartments((prev) => prev.map((dept) => (dept.id === departmentId ? { ...dept, name: newName } : dept)))

    // Update all team members with the old department name
    setTeamMembers((prev) =>
      prev.map((member) => (member.department === oldDepartment.name ? { ...member, department: newName } : member)),
    )
  }

  const handleDeleteDepartment = (departmentId: string) => {
    const department = departments.find((dept) => dept.id === departmentId)
    if (!department) return

    // Check if any team members are assigned to this department
    const membersInDepartment = teamMembers.filter((member) => member.department === department.name)
    if (membersInDepartment.length > 0) {
      alert(
        `Cannot delete department "${department.name}" because ${membersInDepartment.length} team member(s) are assigned to it.`,
      )
      return
    }

    setDepartments((prev) => prev.filter((dept) => dept.id !== departmentId))
  }

  const handleLeaveSubmit = (newLeave: Omit<LeaveRequest, "id" | "submittedDate">) => {
    const leave: LeaveRequest = {
      ...newLeave,
      id: Date.now().toString(),
      submittedDate: new Date().toISOString().split("T")[0],
    }
    setLeaveRequests((prev) => [...prev, leave])
  }

  const handleEditLeave = (updatedLeave: LeaveRequest) => {
    setLeaveRequests((prev) => prev.map((leave) => (leave.id === updatedLeave.id ? updatedLeave : leave)))
  }

  const handleDeleteLeave = (leaveId: string) => {
    setLeaveRequests((prev) => prev.filter((leave) => leave.id !== leaveId))
  }

  // Show loading state while data is being loaded
  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Calendar className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-spin" />
          <p className="text-gray-600">Loading team data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Team Leave Manager</h1>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-500">{teamMembers.length} team members</div>
              <div className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded">✓ Auto-saved</div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="calendar" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="calendar" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Leave Calendar
            </TabsTrigger>
            <TabsTrigger value="request" className="flex items-center gap-2">
              <PlusCircle className="h-4 w-4" />
              Request Leave
            </TabsTrigger>
            <TabsTrigger value="team" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Team Overview
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Admin
            </TabsTrigger>
          </TabsList>

          <TabsContent value="calendar" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Leave Calendar</CardTitle>
                <CardDescription>View and manage all team leave requests - click on any leave to edit</CardDescription>
              </CardHeader>
              <CardContent>
                <LeaveCalendar
                  leaveRequests={leaveRequests}
                  teamMembers={teamMembers}
                  onEditLeave={handleEditLeave}
                  onDeleteLeave={handleDeleteLeave}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="request" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Submit Leave Request</CardTitle>
                <CardDescription>Request time off and specify the dates and reason</CardDescription>
              </CardHeader>
              <CardContent>
                <LeaveForm teamMembers={teamMembers} departments={departments} onSubmit={handleLeaveSubmit} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            <TeamOverview
              teamMembers={teamMembers}
              leaveRequests={leaveRequests}
              onEditLeave={handleEditLeave}
              onDeleteLeave={handleDeleteLeave}
            />
          </TabsContent>

          <TabsContent value="admin" className="space-y-6">
            <AdminPanel
              teamMembers={teamMembers}
              departments={departments}
              onAddMember={handleAddMember}
              onEditMember={handleEditMember}
              onDeleteMember={handleDeleteMember}
              onAddDepartment={handleAddDepartment}
              onEditDepartment={handleEditDepartment}
              onDeleteDepartment={handleDeleteDepartment}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
