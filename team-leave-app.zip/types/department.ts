export type Department = {
  id: string
  name: string
  createdDate: string
}
